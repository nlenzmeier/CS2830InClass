<?php
	
	sleep(3); 
	
	// print "<img class='centeredImage' src='home.jpg' alt='Dino'><br>";
//     print "This application provides information about dinosaurs<br><br>";
//     print "<img class='centeredImage' src='dinotrain.jpg' alt='Dino'><br>";
?>